The provided Files/Directories are:

- app_icons
	Here you will find several icons for several file types.
	Just upload them to your images directory. Please read the User Guide if
	you do not know how to use icons for presenting attachment data or how to
	setup images for Extension Groups.

	Thanks goes to stitch626 for providing this images. :)

